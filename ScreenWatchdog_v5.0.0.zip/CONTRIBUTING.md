# 贡献指南

感谢你对 ScreenWatchdog 的兴趣！请按以下流程贡献：

## 提交 PR 前

1. **新增检测特征**：优先修改 `config/patterns.json`，无需动代码
2. **新增检测逻辑**：修改 `src/` 下脚本，并保证：
   - 通过 `Invoke-ScriptAnalyzer -Path ./src -Recurse -Severity Error`（无 Error）
   - 新增函数/正则需配套 Pester 测试（`tests/`）
   - 新增检查项须带误报抑制（白名单/签名/路径三重判定）
3. **可复现性**：新增开关须同步更新 README 参数表与 CHANGELOG

## 测试

```powershell
Install-Module Pester -Force -Scope CurrentUser
Invoke-Pester ./tests -CI
```

## 代码规范

- 兼容 Windows PowerShell 5.1（不得使用 `??`、`&&`、三元运算符等 PS7 语法）
- 文件统一 UTF-8 with BOM（PowerShell 5.1 中文兼容性）
- 危险操作（修改系统）一律禁止，本项目保持只读
- 涉及证据的导出需附带 SHA256
