# Changelog

本项目遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

## [5.0.0] - 2026-10-17

### 工程化重构
- 项目化为 GitHub 标准结构（src/config/tests/docs/.github）
- 特征库外置 `config/patterns.json`，支持热更新
- 新增 `-OutputJson` 结构化输出（对接 SIEM）
- 共享函数模块 `src/Common.ps1`（特征加载 / Beacon 统计 / 日志）
- Pester 单元测试 + GitHub Actions CI（PSScriptAnalyzer + Pester）
- 全部脚本补充标准 comment-based help 与 MIT 许可证头

### 修复
- `[regex]'...'.Match()` 缺括号导致 RDP 事件/4625 统计失败
- 服务路径 `"path" args` 形式解析失败（Test-Path 非法字符）
- 两处正则非法转义（`\` 结尾、`\T`）
- COM 劫持空值未防护、LSA 空字符串误报、VMICTimeProvider 白名单缺失
- UTF-8 无 BOM 在 PowerShell 5.1 下解析乱码

### 历史版本
- 4.x：扩展持久化检测（IFEO/AppInit/Winlogon/LSA 等 11 项）、基线 Diff、DeepBlueCLI 启发式
- 3.x：首次完整审计模式
