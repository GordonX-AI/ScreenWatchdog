# 使用手册（Usage）

## 运行前提

- Windows 10/11，PowerShell 5.1+（Win11 自带）
- **管理员身份**运行（事件日志与签名校验需要提权）

## 审计模式（Invoke-ScreenAudit.ps1）

| 参数 | 说明 |
|---|---|
| `-OutputDir <path>` | 报告输出目录 |
| `-EventDays <n>` | 事件回溯天数（默认 14） |
| `-ExportBaseline` | 导出持久化基线（干净机一次） |
| `-BaselinePath <path>` | 基线文件位置 |
| `-CompareBaseline` | 对比基线，仅报新增持久化项 |
| `-OutputJson` | 额外输出 audit_result.json |

输出物：`AuditReport.txt`（全量）、`findings.txt`（分级汇总）、`network.csv`、`manifest.json`（含版本/主机/哈希，保证可重复）。

## 监控模式（Start-ScreenMonitor.ps1）

| 参数 | 说明 |
|---|---|
| `-WorkDir <path>` | 日志目录 |
| `-PollSeconds <n>` | 轮询间隔（默认 20） |
| `-BeaconWindowMinutes <n>` | Beacon 分析窗口（默认 45） |
| `-RegisterAutostart` | 注册登录自启 |

按 Q 退出；`Select-String monitor.log -Pattern 'ALERT'` 翻查告警。

## 常见误报处置

| 现象 | 原因 |
|---|---|
| 加速器驱动反复出现在基线 diff | 加速器更新会重装内核驱动，确认时间吻合即可忽略 |
| svchost 共享进程服务被 FP-SUPPRESS | 名称命中特征但为系统宿主进程，看 DisplayName 复核 |
| SCM Event Log WMI 消费者 | Windows 自带默认订阅，非恶意 |
