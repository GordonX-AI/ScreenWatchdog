# Pester 5.x tests for ScreenWatchdog
BeforeAll {
    $patternsPath = Join-Path $PSScriptRoot '..' 'config' 'patterns.json'
    $script:Patterns = Get-Content $patternsPath -Raw | ConvertFrom-Json
    . (Join-Path $PSScriptRoot '..' 'src' 'Common.ps1')
}

Describe 'patterns.json' {
    It '包含全部必需字段' {
        foreach ($k in 'remoteProcPatterns','screenProcPatterns','camProcPatterns',
                       'watchListenPorts','beaconWhitelist','psSuspiciousPattern','internalNetRegex') {
            $Patterns.$k | Should -Not -BeNullOrEmpty
        }
    }
    It '进程特征均为小写' {
        foreach ($p in @($Patterns.remoteProcPatterns) + @($Patterns.screenProcPatterns)) {
            $p | Should -Be $p.ToLower()
        }
    }
    It '监听端口表值为已知协议名' {
        foreach ($v in $Patterns.watchListenPorts.PSObject.Properties.Value) {
            $v | Should -Match '^[\w\-/\.\(\)]+$'
        }
    }
    It '内置正则可编译' {
        { [regex]::new($Patterns.psSuspiciousPattern) } | Should -Not -Throw
        { [regex]::new($Patterns.internalNetRegex) }   | Should -Not -Throw
    }
}

Describe 'Common.ps1 / Test-BeaconPattern' {
    It '样本不足返回 False' {
        Test-BeaconPattern -Intervals @(30,31) | Should -BeFalse
    }
    It '均匀周期返回 True' {
        Test-BeaconPattern -Intervals @(60,60,60,60,60,60,60) | Should -BeTrue
    }
    It '随机间隔返回 False' {
        Test-BeaconPattern -Intervals @(15,300,42,800,23,400,60) | Should -BeFalse
    }
    It '过密间隔返回 False（低于最小周期）' {
        Test-BeaconPattern -Intervals @(5,5,5,5,5,5,5) -MinMeanSec 30 | Should -BeFalse
    }
}

Describe 'Common.ps1 / Get-SwPath' {
    It '脚本目录内解析正常' {
        Get-SwPath -Name 'config/patterns.json' | Should -Exist
    }
}
