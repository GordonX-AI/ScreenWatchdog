﻿<#
.SYNOPSIS
    ScreenWatchdog - 远程监控风险常驻监控（事件增量 + 快照 Diff + Beacon 分析）
.DESCRIPTION
    事件增量监听（远程登录 4624、新服务 7045、新计划任务 106、WMI 订阅 5861）、
    RDP 开关守护、远控/录屏特征进程实时监控、高危端口监听 Diff、
    RITA 式周期性外连(beacon)检测、摄像头/麦克风使用痕迹变化检测。
    特征库外置 config/patterns.json 可热更新。
.PARAMETER WorkDir
    日志目录，默认桌面 SecurityMonitor
.PARAMETER PollSeconds
    轮询间隔秒数，默认 20
.PARAMETER BeaconWindowMinutes
    Beacon 分析时间窗（分钟），默认 45
.PARAMETER RegisterAutostart
    注册当前用户登录自启计划任务
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\src\Start-ScreenMonitor.ps1
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\src\Start-ScreenMonitor.ps1 -RegisterAutostart
.NOTES
    版本 5.0.0 / MIT License / 纯只读监控，不修改系统
    按 Q 退出；日志含全部事件，告警行带 [ALERT] 标记可用 Select-String 翻查。
#>
[CmdletBinding()]
param(
    [string]$WorkDir = "$env:USERPROFILE\Desktop\SecurityMonitor",
    [int]$PollSeconds = 20,
    [int]$BeaconWindowMinutes = 45,
    [switch]$RegisterAutostart
)

. (Join-Path $PSScriptRoot 'Common.ps1')
$ErrorActionPreference = 'Continue'
$WarningPreference     = 'SilentlyContinue'

if (-not (Test-Path $WorkDir)) { New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null }
$LogFile = Join-Path $WorkDir 'monitor.log'

# ------------------------------------------------------------------ 工具函数
function Write-Log([string]$Msg, [string]$Color = 'Gray') {
    $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Host $line -ForegroundColor $Color
}
$script:AlertDedup = @{}
function Send-Alert([string]$Level, [string]$Msg) {
    $key = "$Level|$Msg"
    $now = Get-Date
    if ($script:AlertDedup.ContainsKey($key)) {
        if (($now - $script:AlertDedup[$key]).TotalMinutes -lt 30) { return }
    }
    $script:AlertDedup[$key] = $now
    Write-Log "[ALERT][$Level] $Msg" $(if ($Level -eq 'HIGH') {'Red'} elseif ($Level -eq 'MED') {'Yellow'} else {'Cyan'})
}

# ------------------------------------------------------------------ 特征库
Import-SwPatterns
$remoteProcPatterns = @($script:SwPatterns.remoteProcPatterns)
$screenProcPatterns = @($script:SwPatterns.screenProcMonitorPatterns)
$camProcPatterns   = @($script:SwPatterns.camProcPatterns)
$watchListenPorts = @{}
$script:SwPatterns.monitorWatchListenPorts.PSObject.Properties | ForEach-Object { $watchListenPorts[[int]$_.Name] = $_.Value }
$beaconWhitelist  = @($script:SwPatterns.beaconWhitelist)
$internalNetRegex = $script:SwPatterns.internalNetRegex

# 远控特征正则（用于进程名匹配）
$featureRegex = ($remoteProcPatterns + $screenProcPatterns + $camProcPatterns -join '|')

# ------------------------------------------------------------------ 自启动注册
if ($RegisterAutostart) {
    $action  = New-ScheduledTaskAction -Execute 'powershell.exe' `
        -Argument "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`""
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
    $principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" `
        -LogonType Interactive -RunLevel Highest
    Register-ScheduledTask -TaskName 'RemoteScreenMonitor' -Action $action -Trigger $trigger `
        -Principal $principal -Force | Out-Null
    Write-Log "已注册登录自启任务 RemoteScreenMonitor。移除：Unregister-ScheduledTask -TaskName RemoteScreenMonitor -Confirm:`$false" 'Green'
    exit
}

# ------------------------------------------------------------------ 初始化
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log '警告：非管理员运行，事件日志与部分检查不可用。建议用管理员身份运行。' 'Yellow'
}

Write-Log '================================================================' 'Green'
Write-Log " 持续监控启动  轮询=${PollSeconds}s  beacon窗口=${BeaconWindowMinutes}min" 'Green'
Write-Log " 日志: $LogFile   按 Q 退出" 'Green'
Write-Log '================================================================' 'Green'

$script:LastEventCheck   = Get-Date          # 事件增量起点=启动时刻
$script:ListenerSnapshot = @{}               # 高危端口监听基线
$script:ProcSeen         = @{}               # 已知进程名（启动时建立基线）
$script:ConnHistory      = New-Object System.Collections.Generic.List[object]
$script:CamLastState     = $null
$script:MicLastState     = $null

# 建立进程基线（当前已有的不告警，之后新出现且命中特征的才告警）
Get-Process | ForEach-Object { $script:ProcSeen[$_.Name.ToLower()] = $true }

# 摄像头/麦克风初始状态
foreach ($dev in @(@{G='{E5323777-F976-4f5b-9B55-B94699C46E44}'; N='摄像头'; V='Cam'},
                  @{G='{2EEF81BE-33FA-4800-9670-1CD474972C3F}'; N='麦克风'; V='Mic'})) {
    $p = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\$($dev.G)" -ErrorAction SilentlyContinue
    $ft = if ($p) { $p.LastUsedTimeStop } else { 0 }
    if ($dev.V -eq 'Cam') { $script:CamLastState = $ft } else { $script:MicLastState = $ft }
}

# ================================================================== 主循环
while ($true) {
    # ---- 退出键检测 ----
    if ([Console]::KeyAvailable) {
        $k = [Console]::ReadKey($true)
        if ($k.Key -eq 'Q') { Write-Log '用户按 Q 退出监控。' 'Green'; break }
    }
    $loopStart = Get-Date

    # ---- 1. Security 4624 远程登录增量 ----
    try {
        $evts = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624; StartTime=$script:LastEventCheck} -ErrorAction Stop
        foreach ($e in @($evts)) {
            if ($e.Message -match 'Logon Type:\s+(10|7)\b') {
                $seg  = ($e.Message -split 'New Logon:')[-1]
                $user = ([regex]'Account Name:\s+(\S+)').Match($seg).Groups[1].Value
                $ip   = ([regex]'Source Network Address:\s+(\S+)').Match($e.Message).Groups[1].Value
                Send-Alert 'HIGH' "远程登录成功(LogonType=$($Matches[1])) 用户:$user 来源IP:$ip 时间:$($e.TimeCreated)"
            }
        }
    } catch {}

    # ---- 2. System 7045 新服务安装 ----
    try {
        $evts = Get-WinEvent -FilterHashtable @{LogName='System'; Id=7045; StartTime=$script:LastEventCheck} -ErrorAction Stop
        foreach ($e in @($evts)) {
            $svcName = ([regex]'Service Name:\s*([^\r\n]+)').Match($e.Message).Groups[1].Value.Trim()
            $imgPath = ([regex]'Service File Name:\s*([^\r\n]+)').Match($e.Message).Groups[1].Value.Trim()
            if ($imgPath -match '\\Temp\\|\\AppData\\|\\Users\\Public\\|powershell|mshta|\.ps1') {
                Send-Alert 'HIGH' "新服务安装(路径可疑): $svcName -> $imgPath"
            } else {
                Send-Alert 'INFO' "新服务安装: $svcName -> $imgPath"
            }
        }
    } catch {}

    # ---- 3. TaskScheduler 106 新计划任务（非微软路径） ----
    try {
        $evts = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-TaskScheduler/Operational'; Id=106; StartTime=$script:LastEventCheck} -ErrorAction Stop
        foreach ($e in @($evts)) {
            if ($e.Message -notmatch '\\\\Microsoft\\\\' -and $e.Message -notmatch 'MicrosoftEdge|Lenovo|NVIDIA|Mozilla|Kaspersky|Huorong') {
                Send-Alert 'MED' "新计划任务注册(非微软路径): $($e.Message -replace '\s+',' ').Substring(0, [Math]::Min(180, ($e.Message -replace '\s+',' ').Length))"
            }
        }
    } catch {}

    # ---- 4. WMI-Activity 5861 永久事件订阅创建 ----
    try {
        $evts = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-WMI-Activity/Operational'; Id=5861; StartTime=$script:LastEventCheck} -ErrorAction Stop
        foreach ($e in @($evts)) {
            $flat = $e.Message -replace '\s+',' '
            if ($flat -notmatch 'SCM Event Log') {
                Send-Alert 'MED' "新建 WMI 永久事件订阅: $($flat.Substring(0, [Math]::Min(180, $flat.Length)))"
            }
        }
    } catch {}

    $script:LastEventCheck = $loopStart.AddSeconds(-2)   # 2 秒重叠防漏

    # ---- 5. RDP 开关变化 ----
    try {
        $rdpDeny = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -ErrorAction Stop).fDenyTSConnections
        if ($null -ne $script:RdpLastState -and $rdpDeny -ne $script:RdpLastState) {
            if ($rdpDeny -eq 0) { Send-Alert 'HIGH' '远程桌面已被【开启】（fDenyTSConnections=0）！若非本人操作，立即断网排查。' }
            else { Send-Alert 'INFO' '远程桌面已被关闭。' }
        }
        $script:RdpLastState = $rdpDeny
    } catch {}

    # ---- 6. 进程特征扫描 + 新进程发现 ----
    $newFeatureHits = @{}
    foreach ($p in (Get-Process)) {
        $n = $p.Name.ToLower()
        $nl = $n
        if ($nl -match $featureRegex) {
            $newFeatureHits[$nl] = $p
        }
        $script:ProcSeen[$nl] = $true
    }
    if ($newFeatureHits.Count -gt 0) {
        $firstHit = $newFeatureHits.GetEnumerator() | Select-Object -First 1
        $hitPath  = if ($firstHit.Value.Path) { $firstHit.Value.Path } else { 'N/A' }
        Send-Alert 'HIGH' ("远控/录屏特征进程出现: " + (($newFeatureHits.GetEnumerator() | ForEach-Object { "$($_.Key)(PID $($_.Value.Id))" }) -join ', ') + " | 路径: $hitPath")
    }

    # ---- 7. 高危端口监听快照 Diff ----
    $listeners = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue
    $currentWatch = @{}
    foreach ($l in @($listeners)) {
        if ($watchListenPorts.ContainsKey($l.LocalPort)) {
            $currentWatch["$($l.LocalPort)"] = $l.OwningProcess
        }
    }
    foreach ($port in $currentWatch.Keys) {
        if (-not $script:ListenerSnapshot.ContainsKey($port)) {
            $procName = (Get-Process -Id $currentWatch[$port] -ErrorAction SilentlyContinue).Name
            Send-Alert 'HIGH' "高危端口开始监听: $port ($($watchListenPorts[[int]$port])) by $procName"
        }
    }
    $script:ListenerSnapshot = $currentWatch

    # ---- 8. 连接快照入历史 + beacon 分析 ----
    $cutoff = $loopStart.AddMinutes(-$BeaconWindowMinutes)
    $script:ConnHistory.AddRange(@( (Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object {
        $_.OwningProcess -gt 0 -and $_.RemoteAddress -notmatch $internalNetRegex } | ForEach-Object {
            $proc = $null
            try { $proc = Get-Process -Id $_.OwningProcess -ErrorAction Stop } catch {}
            [PSCustomObject]@{
                Time = $loopStart
                Key  = "$($(if ($proc) { $proc.Name } else { 'PID' + $_.OwningProcess }))|$_($_.RemoteAddress)"
                Proc = if ($proc) { $proc.Name } else { 'PID' + $_.OwningProcess }
                Dst  = $_.RemoteAddress
            }
        }) ))
    # 清理窗口外历史
    while ($script:ConnHistory.Count -gt 0 -and $script:ConnHistory[0].Time -lt $cutoff) { $script:ConnHistory.RemoveAt(0) }
    # beacon：按 (进程|目标IP) 分组，窗口内出现 >=8 次、非全勤、间隔 CV<0.25 且不在白名单
    if ($script:ConnHistory.Count -gt 0) {
        $totalRounds = [math]::Max(1, [math]::Floor(($BeaconWindowMinutes * 60) / $PollSeconds))
        foreach ($g in ($script:ConnHistory | Group-Object Key)) {
            $procName = ($g.Name -split '\|')[0]
            if ($beaconWhitelist -contains $procName.ToLower()) { continue }
            if ($g.Count -lt 8) { continue }
            if ($g.Count -ge $totalRounds * 0.95) { continue }   # 全勤=长连接，非心跳
            $times = @($g.Group.Time | Sort-Object)
            $iv = @()
            for ($i = 1; $i -lt $times.Count; $i++) { $iv += ($times[$i] - $times[$i-1]).TotalSeconds }
            if ($iv.Count -lt 6) { continue }
            if (Test-BeaconPattern -Intervals $iv) {
                $mean = ($iv | Measure-Object -Average).Average
                $std  = [math]::Sqrt((($iv | ForEach-Object { [math]::Pow($_ - $mean, 2) }) | Measure-Object -Average).Average)
                $cv   = if ($mean -gt 0) { $std / $mean } else { 1 }
                Send-Alert 'MED' ("疑似周期性外连(beacon): $($g.Name) 窗口内 $($g.Count) 次 平均间隔 $([int]$mean)s 波动系数 $([math]::Round($cv,2))。远程控制心跳常有此特征，核实该进程归属。")
            }
        }
    }

    # ---- 9. 摄像头/麦克风最近使用变化 ----
    foreach ($dev in @(@{G='{E5323777-F976-4f5b-9B55-B94699C46E44}'; N='摄像头'; V='Cam'},
                      @{G='{2EEF81BE-33FA-4800-9670-1CD474972C3F}'; N='麦克风'; V='Mic'})) {
        $p = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\$($dev.G)" -ErrorAction SilentlyContinue
        $ft = if ($p) { $p.LastUsedTimeStop } else { 0 }
        $last = if ($dev.V -eq 'Cam') { $script:CamLastState } else { $script:MicLastState }
        if ($ft -gt 0 -and $ft -ne $last) {
            try {
                $used = [DateTime]::FromFileTimeUtc($ft).ToLocalTime()
                Send-Alert 'MED' "$($dev.N)最近使用时间更新为 $used。若非本人使用，注意偷拍/窃听风险。"
            } catch {}
        }
        if ($dev.V -eq 'Cam') { $script:CamLastState = $ft } else { $script:MicLastState = $ft }
    }

    Start-Sleep -Seconds $PollSeconds
}
