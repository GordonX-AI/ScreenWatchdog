﻿<#
.SYNOPSIS
    ScreenWatchdog 共享函数模块（不可单独执行，由主脚本点源加载）
.DESCRIPTION
    提供：项目路径解析、外置特征库加载（含内置兜底）、RITA 式 Beacon 统计检测。
.NOTES
    版本 5.0.0 / MIT License / 仅用于合法授权的自有设备安全自查
#>

$script:SwVersion  = '5.0.0'
$script:SwPatterns = $null

function Get-SwPath {
    <#
    .SYNOPSIS
        解析相对于项目根目录的文件路径
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Name)
    Join-Path (Split-Path $PSScriptRoot -Parent) $Name
}

function Import-SwPatterns {
    <#
    .SYNOPSIS
        加载 config/patterns.json 特征库，失败时回退内置兜底特征
    #>
    [CmdletBinding()]
    param([string]$Path = (Get-SwPath 'config/patterns.json'))
    if (Test-Path $Path) {
        try {
            $script:SwPatterns = (Get-Content $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
            return
        } catch {
            Write-Warning "patterns.json 解析失败，回退内置特征库: $_"
        }
    } else {
        Write-Warning "patterns.json 未找到（$Path），回退内置特征库"
    }
    # ---- 内置兜底特征库（保持与 config/patterns.json 主键一致） ----
    $script:SwPatterns = [PSCustomObject]@{
        remoteProcPatterns = @('teamviewer','anydesk','sunlogin','todesk','ultraviewer','rustdesk',
            'aeroadmin','splashtop','logmein','gotoassist','screenconnect','vncserver','realvnc',
            'tightvnc','ultravnc','ngrok','frpc','frps','npc','chisel','rathole','oray','dameware','radmin')
        screenProcPatterns = @('obs','obs64','bandicam','camtasia','snagit','screencast','fraps','dxtory',
            'mirillis','wincam','debut','apowersoft','screentogif','captura','sharex','snipaste','xboxgamebar')
        camProcPatterns    = @('webcam','yawcam','manycam','youcam','contacam','ispy','agentdvr')
        watchListenPorts   = [PSCustomObject]@{ '3389'='RDP'; '5900'='VNC'; '5938'='TeamViewer'; '7070'='AnyDesk'; '22'='SSH'; '5985'='WinRM'; '6568'='向日葵' }
        psSuspiciousPattern = 'FromBase64String|-enc\b|-encodedcommand|Invoke-Expression|\biex\b|DownloadString|Net\.WebClient|Start-BitsTransfer|certutil.*-urlcache|invoke-mimikatz'
        internalNetRegex   = '^(127\.|0\.0\.0\.0|::1|192\.168\.|^10\.|^172\.(1[6-9]|2[0-9]|3[01])\.|fe80::|224\.|239\.|255\.255)'
    }
}

function Test-BeaconPattern {
    <#
    .SYNOPSIS
        RITA 式 Beacon 检测：判断连接间隔序列是否具有时间规律性
    .DESCRIPTION
        周期 >= MinMeanSec、样本数达标且变异系数(CV) < MaxCV 时返回 $true。
        变异系数 = 标准差/均值，是识别 C2/远控心跳周期性的统计量。
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][double[]]$Intervals,
        [double]$MinMeanSec = 30,
        [double]$MaxCV      = 0.25,
        [int]$MinSamples    = 7
    )
    if ($Intervals.Count -lt ($MinSamples - 1)) { return $false }
    $mean = ($Intervals | Measure-Object -Average).Average
    if ($mean -lt $MinMeanSec) { return $false }
    $var = ($Intervals | ForEach-Object { [math]::Pow($_ - $mean, 2) } | Measure-Object -Average).Average
    $cv  = if ($mean -gt 0) { [math]::Sqrt($var) / $mean } else { 999 }
    return ($cv -lt $MaxCV)
}
