﻿<#
.SYNOPSIS
    ScreenWatchdog - Windows 远程录屏/远程监控风险深度审计（防御向，只读）
.DESCRIPTION
    11 大类 60+ 检查项：远程访问通道、远控/录屏进程、持久化机制（含扩展持久化）、
    网络外连与代理、登录痕迹（事件启发式）、账户、摄像头/麦克风隐私、持久化基线 Diff。
    特征库外置 config/patterns.json 可热更新；支持 -OutputJson 结构化输出。
.PARAMETER OutputDir
    报告输出目录，默认为桌面 RemoteScreen_Audit_<时间戳>
.PARAMETER EventDays
    事件日志回溯天数，默认 14
.PARAMETER ExportBaseline
    导出持久化基线 CSV（建议在干净系统上执行一次）
.PARAMETER CompareBaseline
    与基线对比，仅报告新增持久化项
.PARAMETER OutputJson
    额外输出 audit_result.json 结构化结果（可对接 SIEM）
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\src\Invoke-ScreenAudit.ps1
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\src\Invoke-ScreenAudit.ps1 -ExportBaseline
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\src\Invoke-ScreenAudit.ps1 -CompareBaseline -OutputJson
.NOTES
    版本 5.0.0 / MIT License / 纯只读审计，不修改系统任何数据
    仅用于合法授权的自有设备安全自查。排查思路借鉴 PersistenceSniper、
    DeepBlueCLI、RITA、sysmon-config 等开源项目。
#>
[CmdletBinding()]
param(
    [string]$OutputDir = "$env:USERPROFILE\Desktop\RemoteScreen_Audit_$(Get-Date -Format 'yyyyMMdd_HHmmss')",
    [int]$EventDays = 14,                     # 事件日志回溯天数
    [switch]$ExportBaseline,                  # 导出持久化基线 CSV（在干净机上用）
    [string]$BaselinePath = "$env:USERPROFILE\Desktop\persist_baseline.csv",
    [switch]$CompareBaseline,                 # 与基线对比，仅报告新增持久化项
    [switch]$OutputJson                       # 额外输出结构化 JSON 结果
)

$ErrorActionPreference = 'Continue'
$WarningPreference     = 'SilentlyContinue'

if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
$ReportFile  = Join-Path $OutputDir 'AuditReport.txt'
$FindingsFile= Join-Path $OutputDir 'findings.txt'
$NetworkCsv  = Join-Path $OutputDir 'network.csv'
. (Join-Path $PSScriptRoot 'Common.ps1')
$AuditStart = Get-Date
$script:Findings = New-Object System.Collections.Generic.List[string]
$script:PersistItems = New-Object System.Collections.Generic.List[object]

function Write-Section([string]$Title) {
    $line = "=" * 78
    Add-Content -Path $ReportFile -Value "`r`n$line`r`n[*] $Title`r`n$line"
    Write-Host "`n=== $Title ===" -ForegroundColor Cyan
}
function Write-Report([string]$Text) {
    Add-Content -Path $ReportFile -Value $Text
    Write-Host $Text
}
function Add-Finding([string]$Severity, [string]$Text) {
    $entry = "[$Severity] $Text"
    $script:Findings.Add($entry)
    Write-Host "    >>> FINDING $entry" -ForegroundColor $(if ($Severity -eq 'HIGH') {'Red'} elseif ($Severity -eq 'MED') {'Yellow'} else {'Gray'})
    Add-Content -Path $ReportFile -Value "    >>> FINDING $entry"
}
function Get-FileSigStatus([string]$Path) {
    try {
        if (Test-Path $Path) {
            $sig = Get-AuthenticodeSignature $Path
            return "$($sig.Status)"
        }
        return 'PathNotFound'
    } catch { return 'CheckError' }
}

# ---------------------------------------------------------------- 0. 运行环境
Write-Section '0. 运行环境与权限'
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$IsAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
Write-Report ("执行时间      : " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
Write-Report ("当前用户      : $env:USERDOMAIN\$env:USERNAME")
Write-Report ("管理员权限    : $IsAdmin")
Write-Report ("主机名        : $env:COMPUTERNAME")
Write-Report ("PowerShell    : $($PSVersionTable.PSVersion)")
$os = Get-CimInstance Win32_OperatingSystem
Write-Report ("操作系统      : $($os.Caption) Build $($os.BuildNumber)")
Write-Report ("系统安装时间: $($os.InstallDate)")
Write-Report ("最近启动时间: $($os.LastBootUpTime)")
Write-Report ("报告输出目录: $OutputDir")
if (-not $IsAdmin) { Add-Finding 'HIGH' '未以管理员权限运行，大量关键检查被跳过。请右键 PowerShell -> 以管理员身份运行后重试。' }
$scriptHash = (Get-FileHash -Path $MyInvocation.MyCommand.Path -Algorithm SHA256).Hash
Write-Report ("本脚本 SHA256 : $scriptHash")

# ------------------------------------------------ 1. 远程访问通道（高危面）
Write-Section '1. 远程访问服务与端口（RDP/WinRM/SSH/远程协助等）'

# 1.1 RDP 服务与配置
$rdpService = Get-Service TermService -ErrorAction SilentlyContinue
Write-Report ("[RDP] TermService 服务状态: $($rdpService.Status) / 启动类型: $($rdpService.StartType)")
$tsReg = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -ErrorAction SilentlyContinue
Write-Report ("[RDP] fDenyTSConnections (0=允许远程桌面): $($tsReg.fDenyTSConnections)")
$rdpNLA = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -ErrorAction SilentlyContinue
Write-Report ("[RDP] SecurityLayer (0=低,1=协商,2=SSL): $($rdpNLA.SecurityLayer)  MinEncryptionLevel: $($rdpNLA.MinEncryptionLevel)")
Write-Report ("[RDP] RDP-Tcp 端口: $($rdpNLA.PortNumber)")
if ($rdpService.Status -eq 'Running') {
    Add-Finding 'INFO' '远程桌面服务处于运行状态。若本人未主动使用 RDP，请结合第 5 节登录日志确认是否被他人使用。'
}

# 1.2 监听端口排查（远控/屏幕共享常用端口）
$watchPorts = @{
    3389='RDP'; 5900='VNC'; 5800='VNC-HTTP'; 5938='TeamViewer'; 7070='AnyDesk';
    22='SSH'; 5985='WinRM-HTTP'; 5986='WinRM-HTTPS'; 445='SMB'; 139='NetBIOS';
    6568='向日葵/Oray'; 21115='RustDesk'; 21116='RustDesk'; 21117='RustDesk';
    4000='NoMachine'; 1494='ICA/Citrix'; 3388='RDP-备用'; 9='Discard'; 8139='VNC?'
}
$listeners = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue
foreach ($l in $listeners) {
    $port = $l.LocalPort
    $proc = $null
    try { $proc = Get-Process -Id $l.OwningProcess -ErrorAction Stop } catch {}
    $procName = if ($proc) { $proc.Name } else { "PID $($l.OwningProcess)" }
    if ($watchPorts.ContainsKey($port)) {
        Add-Finding 'HIGH' "高危端口监听: $port ($($watchPorts[$port])) by $procName (PID $($l.OwningProcess))"
        Write-Report ("[LISTEN-HIGH] Port $port ($($watchPorts[$port])) <= $procName (PID $($l.OwningProcess))")
    } elseif ($port -gt 49152) {
        Write-Report ("[LISTEN] 动态端口 $port <= $procName (PID $($l.OwningProcess))")
    }
}
Write-Report ("[LISTEN] 共 $($listeners.Count) 个监听端口，详见上方。")

# 1.3 远程协助 (Quick Assist / 旧版远程协助)
$raReg = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -ErrorAction SilentlyContinue
Write-Report ("[远程协助] fAllowToGetHelp (0=关闭): $($raReg.fAllowToGetHelp)  fAllowFullControl: $($raReg.fAllowFullControl)")
$raProcs = Get-Process -Name 'msra','QuickAssist','raserver','helpassistant' -ErrorAction SilentlyContinue
if ($raProcs) {
    Add-Finding 'MED' "远程协助进程正在运行: $($raProcs.Name -join ', ')。若非本人发起，立即终止并断网核查。"
}
$qaCapable = Get-AppxPackage -Name '*QuickAssist*' -ErrorAction SilentlyContinue
Write-Report ("[远程协助] Quick Assist 应用包: $(if ($qaCapable) {'已安装'} else {'未安装'})")

# 1.4 WinRM / SSH / 其他远程管理服务
foreach ($svc in 'WinRM','sshd','Telnet','SessionEnv','UmRdpService') {
    $s = Get-Service $svc -ErrorAction SilentlyContinue
    if ($s) {
        Write-Report ("[服务] $svc : $($s.Status) / $($s.StartType)")
        if ($s.Status -eq 'Running' -and $svc -in 'WinRM','sshd','Telnet') {
            Add-Finding 'MED' "远程管理服务 $svc 正在运行。确认是否本人配置。"
        }
    }
}

# 1.5 SMB 会话与隐藏共享
$shares = net share 2>$null
Write-Report "[SMB] 共享列表:`r`n$shares"
$sessions = net session 2>$null
Write-Report "[SMB] 活跃会话:`r`n$sessions"
if ($sessions -match '\\\\') { Add-Finding 'HIGH' "存在其他机器到本机的 SMB 会话，可能存在远程管理行为。" }

# ------------------------------------------------ 2. 进程排查（远控/录屏/偷拍）
Write-Section '2. 进程排查（远控工具 / 录屏截屏 / 摄像头相关）'

Import-SwPatterns
$remoteProcPatterns = @($script:SwPatterns.remoteProcPatterns)
$screenProcPatterns = @($script:SwPatterns.screenProcPatterns)
$camProcPatterns   = @($script:SwPatterns.camProcPatterns)
$watchPorts = @{}
$script:SwPatterns.watchListenPorts.PSObject.Properties | ForEach-Object { $watchPorts[[int]$_.Name] = $_.Value }
$internalNetRegex = $script:SwPatterns.internalNetRegex
$listeners = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue
foreach ($l in $listeners) {
    $port = $l.LocalPort
    $proc = $null
    try { $proc = Get-Process -Id $l.OwningProcess -ErrorAction Stop } catch {}
    $procName = if ($proc) { $proc.Name } else { "PID $($l.OwningProcess)" }
    if ($watchPorts.ContainsKey($port)) {
        Add-Finding 'HIGH' "高危端口监听: $port ($($watchPorts[$port])) by $procName (PID $($l.OwningProcess))"
        Write-Report ("[LISTEN-HIGH] Port $port ($($watchPorts[$port])) <= $procName (PID $($l.OwningProcess))")
    } elseif ($port -gt 49152) {
        Write-Report ("[LISTEN] 动态端口 $port <= $procName (PID $($l.OwningProcess))")
    }
}
Write-Report ("[LISTEN] 共 $($listeners.Count) 个监听端口，详见上方。")

# 1.3 远程协助 (Quick Assist / 旧版远程协助)
$raReg = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -ErrorAction SilentlyContinue
Write-Report ("[远程协助] fAllowToGetHelp (0=关闭): $($raReg.fAllowToGetHelp)  fAllowFullControl: $($raReg.fAllowFullControl)")
$raProcs = Get-Process -Name 'msra','QuickAssist','raserver','helpassistant' -ErrorAction SilentlyContinue
if ($raProcs) {
    Add-Finding 'MED' "远程协助进程正在运行: $($raProcs.Name -join ', ')。若非本人发起，立即终止并断网核查。"
}
$qaCapable = Get-AppxPackage -Name '*QuickAssist*' -ErrorAction SilentlyContinue
Write-Report ("[远程协助] Quick Assist 应用包: $(if ($qaCapable) {'已安装'} else {'未安装'})")

# 1.4 WinRM / SSH / 其他远程管理服务
foreach ($svc in 'WinRM','sshd','Telnet','SessionEnv','UmRdpService') {
    $s = Get-Service $svc -ErrorAction SilentlyContinue
    if ($s) {
        Write-Report ("[服务] $svc : $($s.Status) / $($s.StartType)")
        if ($s.Status -eq 'Running' -and $svc -in 'WinRM','sshd','Telnet') {
            Add-Finding 'MED' "远程管理服务 $svc 正在运行。确认是否本人配置。"
        }
    }
}

# 1.5 SMB 会话与隐藏共享
$shares = net share 2>$null
Write-Report "[SMB] 共享列表:`r`n$shares"
$sessions = net session 2>$null
Write-Report "[SMB] 活跃会话:`r`n$sessions"
if ($sessions -match '\\\\') { Add-Finding 'HIGH' "存在其他机器到本机的 SMB 会话，可能存在远程管理行为。" }

# ------------------------------------------------ 2. 进程排查（远控/录屏/偷拍）
Write-Section '2. 进程排查（远控工具 / 录屏截屏 / 摄像头相关）'

$remoteProcPatterns = @(
    'teamviewer','anydesk','sunlogin','todesk','ultraviewer','rustdesk','aeroadmin',
    'splashtop','logmein','gotoassist','bomgar','beyondtrust','screenconnect','connectwise',
    'ammyy','chrome-remote-desktop','remotepc','realvnc','tightvnc','ultravnc','vncserver',
    'ngrok','frpc','frps','npc','chisel','rathole','lanproxy','natapp','花生壳','oray',
    'pcanywhere','dameware','radmin','r_server','remotely','meshagent','tacticalrmm'
)
$screenProcPatterns = @(
    'obs','obs64','bandicam','camtasia','snagit','screencast','fraps','action!','action_x64',
    'dxtory','mirillis','wincam','debut','srecorder','smartrecorder','apowersoft','verycapture',
    'screentogif','captura','sharex','flameshot','snipaste','xboxgamebar','gamebar',
    'screengrab','printscreen','faststone','lightshot','greenshot','monosnap','nimbus'
)
$camProcPatterns = @('webcam','camera','yawcam','ivideon','manycam','youcam','contacam','netcam','ispy','agentdvr','shinobi')

$allProc = Get-CimInstance Win32_Process | Select-Object ProcessId,Name,ExecutablePath,CommandLine,ParentProcessId
Write-Report ("进程总数: $($allProc.Count)")

foreach ($p in $allProc) {
    $n = $p.Name.ToLower()
    $hit = $null; $cat = $null
    foreach ($pat in $remoteProcPatterns) { if ($n -like "*$pat*") { $hit = $pat; $cat = '远程控制'; break } }
    if (-not $hit) { foreach ($pat in $screenProcPatterns) { if ($n -like "*$pat*") { $hit = $pat; $cat = '录屏截屏'; break } } }
    if (-not $hit) { foreach ($pat in $camProcPatterns) { if ($n -like "*$pat*") { $hit = $pat; $cat = '摄像头'; break } } }
    if ($hit) {
        $sig = Get-FileSigStatus $p.ExecutablePath
        Add-Finding $(if ($cat -eq '远程控制') {'HIGH'} else {'MED'}) "运行中的${cat}进程: $($p.Name) (PID $($p.ProcessId)) 路径: $($p.ExecutablePath) 签名状态: $sig"
        Write-Report ("[PROC-$cat] $($p.Name) PID=$($p.ProcessId) Path=$($p.ExecutablePath) Sig=$sig")
        Write-Report ("           CMD: $($p.CommandLine)")
    }
}

# 2.2 无数字签名或签名失效的可疑进程（重点：位于临时目录/用户目录的）
Write-Report "`n--- 无签名进程清单（重点核查路径位于 Temp/AppData 的） ---"
foreach ($p in $allProc) {
    if (-not $p.ExecutablePath) { continue }
    if ($p.ExecutablePath -notmatch '^[A-Za-z]:\\') { continue }
    $sig = Get-AuthenticodeSignature $p.ExecutablePath
    if ($sig.Status -ne 'Valid') {
        $risky = $p.ExecutablePath -match '\\Temp\\|\\AppData\\|\\Users\\Public\\|\\ProgramData\\[^\\]+\\[^\\]+\.(exe|dll)'
        $flag = if ($risky) { 'HIGH' } else { 'INFO' }
        if ($risky) {
            Add-Finding 'HIGH' "无有效签名进程且位于高风险目录: $($p.Name) -> $($p.ExecutablePath)"
        }
        Write-Report ("[NOSIG-$flag] $($p.Name) PID=$($p.ProcessId) Path=$($p.ExecutablePath)")
    }
}

# ------------------------------------------------ 3. 服务与驱动排查
Write-Section '3. 服务与驱动（持久化排查）'

$svcList = Get-CimInstance Win32_Service | Select-Object Name,State,StartMode,PathName,StartName
foreach ($sv in $svcList) {
    if ($sv.State -ne 'Running') { continue }
    $script:PersistItems.Add([PSCustomObject]@{ Type='Service'; Name=$sv.Name; Detail=$sv.PathName })
    if ($sv.PathName -match '^"([^"]+)"') { $path = $Matches[1] }
    else { $path = ($sv.PathName -split '\s+')[0] }
    if ($path -match '%') { $path = [Environment]::ExpandEnvironmentVariables($path) }
    $nameLow = $sv.Name.ToLower()
    $sus = $false
    foreach ($pat in $remoteProcPatterns) { if ($nameLow -like "*$pat*") { $sus = $true; break } }
    $inRiskyDir = $path -match '\\Temp\\|\\AppData\\|\\Users\\Public\\'
    $sig = Get-FileSigStatus $path
    if ($sus -and $path -match 'svchost\.exe$') {
        Write-Report ("[FP-SUPPRESS] $($sv.Name) 为 svchost 共享进程服务，名称特征疑误报，请查 DisplayName 复核")
        $sus = $false
    }
    if ($sus) {
        Add-Finding 'HIGH' "远控相关服务运行中: $($sv.Name) -> $path (签名:$sig)"
    } elseif ($inRiskyDir -or $sig -eq 'NotSigned') {
        Add-Finding 'MED' "可疑服务: $($sv.Name) 路径:$path 签名:$sig"
    }
}
Write-Report ("服务总数: $($svcList.Count)，运行中: $(($svcList | Where-Object State -eq 'Running').Count)")

Write-Report "`n--- 内核驱动快速筛查（非 Microsoft 签名） ---"
$drivers = Get-CimInstance Win32_SystemDriver | Where-Object { $_.State -eq 'Running' }
foreach ($d in $drivers) {
    if ($d.PathName -match 'system32\\drivers' -and $d.Name -match '^(tcpip|disk|partmgr|volmgr|nvme|stornvme|wdf|ksecdd|msrpc|afd|netbt|wanarp|ndis|fltMgr|CLFS|CI|Wof|FileInfo|WdFilter|WdBoot)$') { continue }
    $path = $d.PathName -replace '\\SystemRoot\\', "$env:SystemRoot\" -replace '^\?\?\\',''
    $sig = Get-FileSigStatus $path
    if ($sig -eq 'NotSigned' -or $sig -eq 'HashMismatch') {
        Add-Finding 'MED' "非签名驱动运行中: $($d.Name) -> $path (状态:$($d.State))"
        Write-Report ("[DRIVER-NOSIG] $($d.Name) $path")
    }
}

# ------------------------------------------------ 4. 持久化机制
Write-Section '4. 持久化机制（自启动 / 计划任务 / WMI 事件订阅）'

Write-Report "--- 注册表 Run 键（当前用户 + 所有用户） ---"
$runKeys = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
)
foreach ($k in $runKeys) {
    $props = Get-ItemProperty $k -ErrorAction SilentlyContinue
    if ($props) {
        $props.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
            Write-Report ("[RUN] $($_.Name) = $($_.Value)")
            $script:PersistItems.Add([PSCustomObject]@{ Type='RunKey'; Name="$k\$($_.Name)"; Detail="$($_.Value)" })
            if ($_.Value -match '\\Temp\\|\\AppData\\.*\.(exe|ps1|vbs|js|bat|dll)|powershell.*-enc|frombase64') {
                Add-Finding 'HIGH' "Run 键可疑条目: $($_.Name) = $($_.Value)"
            }
        }
    }
}

Write-Report "`n--- 启动文件夹 ---"
$startupDirs = @("$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup",
                  "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp")
foreach ($d in $startupDirs) {
    if (Test-Path $d) {
        Get-ChildItem $d -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
            Write-Report ("[STARTUP] $($_.FullName)")
            $script:PersistItems.Add([PSCustomObject]@{ Type='StartupFolder'; Name=$_.FullName; Detail=$_.Extension })
            if ($_.Extension -match '\.exe|\.ps1|\.vbs|\.js|\.bat|\.scr') {
                $sig = Get-FileSigStatus $_.FullName
                Add-Finding $(if ($sig -ne 'Valid') {'HIGH'} else {'INFO'}) "启动文件夹可执行项: $($_.Name) 签名:$sig"
            }
        }
    }
}

Write-Report "`n--- 计划任务（非微软 + 可疑路径 + 最近运行记录） ---"
try {
    $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.State -ne 'Disabled' }
    foreach ($t in $tasks) {
        $actions = $t.Actions | ForEach-Object { $_.Execute + ' ' + $_.Arguments }
        $sus = $false
        if ($t.TaskPath -notlike '\Microsoft*') {
            foreach ($a in $actions) {
                if ($a -match '\\Temp\\|\\AppData\\|\\Users\\Public\\|powershell|cmd\.exe|wscript|cscript|rundll32|regsvr32|mshta|wmic|bitsadmin|certutil') {
                    $sus = $true; break
                }
            }
            $info = $t | Get-ScheduledTaskInfo -ErrorAction SilentlyContinue
            Write-Report ("[TASK] $($t.TaskPath)$($t.TaskName) | 状态:$($t.State) | 上次运行:$($info.LastRunTime) | 命令:$($actions -join ' ; ')")
            $script:PersistItems.Add([PSCustomObject]@{ Type='ScheduledTask'; Name="$($t.TaskPath)$($t.TaskName)"; Detail=($actions -join ' ; ') })
            if ($sus) { Add-Finding 'HIGH' "可疑计划任务: $($t.TaskPath)$($t.TaskName) -> $($actions -join ' ; ')" }
        }
    }
} catch { Write-Report "[TASK] 枚举失败: $_" }

Write-Report "`n--- WMI 事件订阅（无文件持久化后门常用） ---"
try {
    $filters = Get-WmiObject -Namespace root\subscription -Class __EventFilter
    $consumers = Get-WmiObject -Namespace root\subscription -Class __EventConsumer
    $bindings = Get-WmiObject -Namespace root\subscription -Class __FilterToConsumerBinding
    Write-Report ("WMI 过滤器: $(@($filters).Count) | 消费者: $(@($consumers).Count) | 绑定: $(@($bindings).Count)")
    foreach ($c in $consumers) {
        Write-Report ("[WMI-CONSUMER] $($c.Name) Type=$($c.__CLASS)")
        $cmd = $c.CommandLineTemplate
        if ($cmd) {
            Write-Report ("             CMD: $cmd")
            if ($cmd -match 'powershell|cmd|wscript|mshta|curl|wget|bitsadmin') { Add-Finding 'HIGH' "WMI 事件消费者执行命令: $cmd" }
        }
    }
    foreach ($c in @($consumers)) {
        $script:PersistItems.Add([PSCustomObject]@{ Type='WmiConsumer'; Name=$c.Name; Detail=$c.__CLASS })
    }
    $nonSystemConsumers = @($consumers) | Where-Object { $_.Name -notmatch '^SCM Event Log' }
    if (@($bindings).Count -gt 0 -and $nonSystemConsumers.Count -gt 0) {
        Add-Finding 'MED' "存在非系统默认的 WMI 事件订阅: $($nonSystemConsumers.Name -join ', ')。多数良性软件不建订阅，请逐一核对。"
    }
} catch { Write-Report "[WMI] 枚举失败: $_" }

# 4b. 扩展持久化检测（检测面借鉴 PersistenceSniper / Hexacorn 系列）
Write-Report "`n--- 扩展持久化检测（IFEO / AppInit / Winlogon / LSA / BootExecute 等） ---"

# IFEO 调试器劫持 + GlobalFlag(SilentProcessExit 前置)
Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options' -ErrorAction SilentlyContinue | ForEach-Object {
    $ifeoDbg = (Get-ItemProperty $_.PSPath -Name Debugger -ErrorAction SilentlyContinue).Debugger
    if ($ifeoDbg) {
        Add-Finding 'HIGH' "IFEO Debugger 劫持: $($_.PSChildName) -> $ifeoDbg"
        Write-Report ("[IFEO] $($_.PSChildName) Debugger=$ifeoDbg")
    }
    $gflag = (Get-ItemProperty $_.PSPath -Name GlobalFlag -ErrorAction SilentlyContinue).GlobalFlag
    if ($gflag -band 0x200) {
        Write-Report ("[IFEO] $($_.PSChildName) GlobalFlag=0x$('{0:X}' -f $gflag) （含 SilentProcessExit 监控位，需配合下方键核查）")
    }
}
# SilentProcessExit
Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SilentProcessExit' -ErrorAction SilentlyContinue | ForEach-Object {
    $mon = (Get-ItemProperty $_.PSPath -Name MonitorProcess -ErrorAction SilentlyContinue).MonitorProcess
    if ($mon) {
        Add-Finding 'HIGH' "SilentProcessExit 劫持: $($_.PSChildName) -> $mon"
        Write-Report ("[SPE] $($_.PSChildName) MonitorProcess=$mon")
    }
}
# AppInit_DLLs（Win10/11 默认应为空）
$appInit = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows' -ErrorAction SilentlyContinue
if ($appInit.LoadAppInit_DLLs -eq 1 -and $appInit.AppInit_DLLs) {
    Add-Finding 'HIGH' "AppInit_DLLs 被启用: $($appInit.AppInit_DLLs)"
    Write-Report ("[APPINIT] LoadAppInit_DLLs=1 DLLs=$($appInit.AppInit_DLLs)")
}
# AppCertDlls
Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\AppCertDlls' -ErrorAction SilentlyContinue | ForEach-Object {
    $dll = (Get-ItemProperty $_.PSPath).$($_.PSChildName)
    Add-Finding 'HIGH' "AppCertDlls 存在条目: $($_.PSChildName)=$dll"
}
# Winlogon Shell / Userinit / GinaDLL
$wl = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -ErrorAction SilentlyContinue
if ($wl.Shell -and $wl.Shell -ne 'explorer.exe') { Add-Finding 'HIGH' "Winlogon Shell 被篡改: $($wl.Shell)" }
if ($wl.Userinit -and $wl.Userinit -notmatch '^C:\\Windows\\system32\\userinit\.exe,?$') { Add-Finding 'HIGH' "Winlogon Userinit 被篡改: $($wl.Userinit)" }
if ($wl.GinaDLL) { Add-Finding 'HIGH' "Winlogon GinaDLL（经典劫持位）: $($wl.GinaDLL)" }
# LSA 包
$lsa = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -ErrorAction SilentlyContinue
if ($lsa.'Authentication Packages' -and (($lsa.'Authentication Packages') -join ' ') -notmatch '^msv1_0$') {
    Write-Report ("[LSA] Authentication Packages: $(($lsa.'Authentication Packages') -join ', ')")
    if (($lsa.'Authentication Packages') -join ' ' -notmatch '^msv1_0') { Add-Finding 'MED' "LSA Authentication Packages 含非默认项" }
}
if ($lsa.'Notification Packages' -and (($lsa.'Notification Packages') -join ' ') -notmatch 'scecli') {
    Add-Finding 'MED' "LSA Notification Packages 含非默认项: $(($lsa.'Notification Packages') -join ', ')"
}
$lsaSecPkgs = @($lsa.'Security Packages' | Where-Object { $_ -and $_.Trim() })
if ($lsaSecPkgs.Count -gt 0) {
    $lsaSecJoined = ($lsaSecPkgs | ForEach-Object { $_.Trim() }) -join ' '
    if ($lsaSecJoined -notmatch '^(negotiate|kerberos|msv1_0|schannel|wdigest|tspkg|pku2u)') {
        Add-Finding 'MED' "LSA Security Packages 含非默认项: $($lsaSecJoined)"
    }
}
# BootExecute
$sm = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -ErrorAction SilentlyContinue
$bx = ($sm.BootExecute -join ' ').Trim()
if ($bx -and $bx -notmatch '^autocheck autochk \*$') {
    Add-Finding 'HIGH' "BootExecute 非默认值: $bx"
    Write-Report ("[BOOTEXEC] $bx")
}
# Print Monitors
Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors' -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -notmatch 'Standard TCP/IP Port' } | ForEach-Object {
    $dll = (Get-ItemProperty $_.PSPath -Name Driver -ErrorAction SilentlyContinue).Driver
    if ($dll -and $dll -notmatch '^%SystemRoot%\\\\System32') {
        Add-Finding 'MED' "Print Monitor 可疑 DLL: $($_.PSChildName) -> $dll"
    }
}
# W32Time TimeProviders
Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders' -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -notin 'NtpClient','NtpServer','VMICTimeProvider','VmiTimeProvider' } | ForEach-Object {
    $dll = (Get-ItemProperty $_.PSPath -Name DllName -ErrorAction SilentlyContinue).DllName
    Add-Finding 'MED' "非常规 TimeProvider: $($_.PSChildName) -> $dll"
}
# Office 加载项（Word/Excel/PowerPoint，HKCU+HKLM+32位视图）
$officeAddinRoots = @(
    'HKCU:\Software\Microsoft\Office\Word\Addins','HKCU:\Software\Microsoft\Office\Excel\Addins','HKCU:\Software\Microsoft\Office\PowerPoint\Addins',
    'HKLM:\SOFTWARE\Microsoft\Office\Word\Addins','HKLM:\SOFTWARE\Microsoft\Office\Excel\Addins','HKLM:\SOFTWARE\Microsoft\Office\PowerPoint\Addins',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\Word\Addins','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\Excel\Addins'
)
foreach ($oar in $officeAddinRoots) {
    Get-ChildItem $oar -ErrorAction SilentlyContinue | ForEach-Object {
        $mani = (Get-ItemProperty $_.PSPath -Name Manifest -ErrorAction SilentlyContinue).Manifest
        $lb   = (Get-ItemProperty $_.PSPath -Name LoadBehavior -ErrorAction SilentlyContinue).LoadBehavior
        if ($lb -eq 3 -and $mani -match 'file:///(.*\.\w+)' ) {
            $dllPath = $Matches[1] -replace '/','\'
            if ($dllPath -match '\Temp\|\AppData\|\Users\Public\') {
                Add-Finding 'HIGH' "Office 加载项指向高风险路径: $oar\$($_.PSChildName) -> $dllPath"
            }
        }
        Write-Report ("[OFFICE-ADDIN] $oar\$($_.PSChildName) LoadBehavior=$lb Manifest=$mani")
    }
}
# COM 劫持抽查：HKCU\Software\Classes\CLSID 下 InprocServer32 指向可疑路径
Write-Report "--- COM 劫持抽查（HKCU Classes，仅报告 Temp/AppData 路径） ---"
Get-ChildItem 'HKCU:\Software\Classes\CLSID' -ErrorAction SilentlyContinue | ForEach-Object {
    $comItem = Get-Item "$($_.PSPath)\InprocServer32" -ErrorAction SilentlyContinue
    $ips = if ($comItem) { $comItem.GetValue('') } else { $null }
    if ($ips -and $ips -match '\\Temp\\|\\AppData\\') {
        Add-Finding 'HIGH' "COM InprocServer32 指向可疑路径: $($_.PSChildName) -> $ips"
        Write-Report ("[COM-HIJACK] $($_.PSChildName) -> $ips")
    }
}

# ------------------------------------------------ 5. 网络排查
Write-Section '5. 网络连接与代理（外连排查）'

$conns = Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object { $_.State -eq 'Established' }
$connRows = @()
foreach ($c in $conns) {
    $proc = $null
    try { $proc = Get-Process -Id $c.OwningProcess -ErrorAction Stop } catch {}
    $row = [PSCustomObject]@{
        LocalAddress  = "$($c.LocalAddress):$($c.LocalPort)"
        RemoteAddress = "$($c.RemoteAddress):$($c.RemotePort)"
        State         = $c.State
        Process       = if ($proc) { $proc.Name } else { "PID $($c.OwningProcess)" }
        PID           = $c.OwningProcess
        ProcessPath   = if ($proc) { $proc.Path } else { '' }
    }
    $connRows += $row
}
$connRows | Export-Csv -Path $NetworkCsv -NoTypeInformation -Encoding UTF8
Write-Report ("活跃 TCP 连接数: $($connRows.Count)，明细已导出 network.csv")

# 外连归属判断：排除本地/组播地址
foreach ($r in $connRows) {
    if ($r.RemoteAddress -match '^(127\.|0\.0\.0\.0|\[::1\]|::1|224\.|239\.|255\.255|fe80::)') { continue }
    $sus = $false
    foreach ($pat in $remoteProcPatterns) { if ($r.Process -like "*$pat*") { $sus = $true; break } }
    if ($sus) {
        Add-Finding 'HIGH' "远控工具外连: $($r.Process) (PID $($r.PID)) -> $($r.RemoteAddress)"
    } elseif ($r.Process -in @('powershell','pwsh','cmd','wscript','cscript','mshta','rundll32','regsvr32','certutil','bitsadmin','wmic') -and $r.RemoteAddress -notmatch '^(20\.190|40\.|52\.|13\.|40\.126|20\.|51\.)') {
        Add-Finding 'HIGH' "脚本解释器存在外连: $($r.Process) -> $($r.RemoteAddress)（可能为下载/反弹行为）"
    }
}
Write-Report "--- 解释器类进程外连明细 ---"
$connRows | Where-Object { $_.Process -in @('powershell','pwsh','cmd','wscript','cscript','mshta','rundll32','certutil') } |
    ForEach-Object { Write-Report ("[NET-SCRIPT] $($_.Process) -> $($_.RemoteAddress)") }

Write-Report "`n--- 系统代理设置 ---"
$ieProxy = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
Write-Report ("IE/系统代理启用: $($ieProxy.ProxyEnable)  代理地址: $($ieProxy.ProxyServer)  PAC: $($ieProxy.AutoConfigURL)")
if ($ieProxy.ProxyEnable -eq 1 -and $ieProxy.ProxyServer -notmatch '127\.0\.0\.1|localhost') {
    Add-Finding 'MED' "系统代理已启用且非本机回环: $($ieProxy.ProxyServer)。若非本人配置，存在流量劫持/监听风险。"
}
$wpad = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad' -ErrorAction SilentlyContinue
if ($wpad.WPADLastNetworkChangeDetected) { Write-Report ("WPAD 最近变更时间: $($wpad.WPADLastNetworkChangeDetected)") }

Write-Report "`n--- hosts 文件 ---"
$hostsPath = "$env:SystemRoot\System32\drivers\etc\hosts"
$hostsContent = Get-Content $hostsPath -ErrorAction SilentlyContinue | Where-Object { $_ -match '^\s*[^#]' }
Write-Report ($hostsContent -join "`r`n")
if ($hostsContent) {
    foreach ($h in $hostsContent) {
        if ($h -match '(update|microsoft|windows|login|account|security|avast|360|tencent|qq)\.') {
            Add-Finding 'HIGH' "hosts 文件存在安全软件/系统域名重定向: $h"
        }
    }
}

Write-Report "`n--- DNS 服务器与路由异常 ---"
Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.ServerAddresses } |
    ForEach-Object { Write-Report ("[DNS] $($_.InterfaceAlias): $($_.ServerAddresses -join ', ')") }

Write-Report "`n--- DNS 缓存异常（高频重复/长随机域名可能是 DGA/C2） ---"
try {
    $dnsCache = Get-DnsClientCache -ErrorAction Stop
    if ($dnsCache) {
        $topDns = $dnsCache | Group-Object Entry | Sort-Object Count -Descending | Select-Object -First 10
        foreach ($g in $topDns) { Write-Report ("[DNSCACHE] $($g.Name)  x$($g.Count)") }
        $dgaLike = $dnsCache | Where-Object { $_.Entry -match '^[a-z0-9]{25,}\.' -and $_.Entry -notmatch 'cdn|cloudfront|google|microsoft|azure|amazonaws' }
        if ($dgaLike) {
            Add-Finding 'MED' "DNS 缓存中存在疑似 DGA 长随机域名: $(($dgaLike.Entry | Select-Object -First 5) -join ', ')"
        }
    }
} catch { Write-Report "DNS 缓存读取失败: $_" }

# ------------------------------------------------ 6. 远控软件安装痕迹与日志
Write-Section '6. 第三方远控/录屏软件安装痕迹与连接日志'

$toolPatterns = 'TeamViewer|AnyDesk|Sunlogin|向日葵|ToDesk|UltraViewer|RustDesk|Splashtop|LogMeIn|GoTo|AeroAdmin|Chrome Remote Desktop|RemotePC|VNC|Radmin|Dameware|Bomgar|BeyondTrust|ScreenConnect|ConnectWise|Ngrok|frp|Oray|花生壳|TightVNC|UltraVNC|RealVNC|ammyy|AmmyyAdmin'

Write-Report "--- 已安装程序匹配 ---"
$uninstPaths = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
$installed = foreach ($up in $uninstPaths) {
    Get-ItemProperty $up -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName } |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallDate, InstallLocation, UninstallString
}
foreach ($app in $installed) {
    if ($app.DisplayName -match $toolPatterns) {
        Add-Finding 'HIGH' "检测到远控/录屏类软件安装: $($app.DisplayName) v$($app.DisplayVersion) by [$($app.Publisher)] 安装时间:$($app.InstallDate)"
        Write-Report ("[INSTALLED] $($app.DisplayName) | $($app.Publisher) | $((Get-Date $app.InstallDate -Format 'yyyy-MM-dd') ) | $($app.InstallLocation)")
    }
}

Write-Report "`n--- 文件系统残留（Program Files / ProgramData） ---"
$fsRoots = @("$env:ProgramFiles", "$env:ProgramFiles (x86)", "$env:ProgramData", "$env:APPDATA", "$env:LOCALAPPDATA")
foreach ($root in $fsRoots) {
    if (-not (Test-Path $root)) { continue }
    Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.Name -match $toolPatterns) {
            Write-Report ("[FS-DIR] $($_.FullName)")
            Add-Finding 'MED' "远控软件目录残留: $($_.FullName)"
        }
    }
}

Write-Report "`n--- 常见远控连接日志/ID 提取 ---"
$logChecks = @(
    @{Name='AnyDesk 连接记录'; Path='C:\ProgramData\AnyDesk\connection_trace.txt'; Pattern='.*'},
    @{Name='TeamViewer 连接日志'; Path='C:\Program Files\TeamViewer\Connections.txt'; Pattern='.*'},
    @{Name='ToDesk 日志目录'; Path='C:\ProgramData\ToDesk\Logs'; Pattern='.*'},
    @{Name='向日葵日志目录'; Path='C:\ProgramData\Oray\SunloginClient'; Pattern='.*'}
)
foreach ($lc in $logChecks) {
    if (Test-Path $lc.Path) {
        Write-Report ("[LOG] 发现 $($lc.Name): $($lc.Path)")
        Add-Finding 'HIGH' "发现 $($lc.Name)，说明该远控软件至少运行过。应立即打开核对连接时间与对端ID。"
        if ((Get-Item $lc.Path) -is [System.IO.FileInfo]) {
            $tail = Get-Content $lc.Path -Tail 30 -ErrorAction SilentlyContinue
            $tailText = ($tail -join "`r`n")
            Write-Report ("--- 日志末尾 30 行 ---")
            Write-Report $tailText
        }
    }
}
$adId = (Get-ItemProperty 'HKLM:\SOFTWARE\AnyDesk' -Name AnyDeskID -ErrorAction SilentlyContinue).AnyDeskID
if ($adId) { Write-Report ("[AnyDesk ID] $adId"); Add-Finding 'INFO' "本机 AnyDesk ID: ${adId}（他人凭此ID+密码即可连入）" }
$tvId = (Get-ItemProperty 'HKLM:\SOFTWARE\TeamViewer' -Name ClientID -ErrorAction SilentlyContinue).ClientID
if ($tvId) { Write-Report ("[TeamViewer ID] $tvId"); Add-Finding 'INFO' "本机 TeamViewer ID: $tvId" }

# ------------------------------------------------ 7. 登录痕迹排查
Write-Section '7. 登录与远程会话痕迹（事件日志 + RDP 历史）'

# 7.1 当前在线会话
Write-Report "--- 当前登录会话 (quser) ---"
$quser = quser 2>$null
Write-Report ($quser -join "`r`n")
if ($quser -match 'rdp|disc') { Add-Finding 'MED' "当前存在 RDP 类型会话，请核实是否本人登录。" }

# 7.2 MSTSC 连接历史（本机连出去过哪些机器）
Write-Report "`n--- 本机 RDP 客户端连接历史 (MSTSC MRU) ---"
$profiles = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList' -ErrorAction SilentlyContinue
$rdpHistoryFound = $false
foreach ($prof in $profiles) {
    $sid = $prof.PSChildName
    if ($sid -notmatch '^S-1-5-21') { continue }
    $tsPath = "Registry::HKEY_USERS\$sid\Software\Microsoft\Terminal Server Client"
    $default = Get-ItemProperty "$tsPath\Default" -ErrorAction SilentlyContinue
    $servers = Get-ItemProperty "$tsPath\Servers" -ErrorAction SilentlyContinue
    $targets = @()
    if ($default) { $targets += $default.PSObject.Properties | Where-Object { $_.Name -match '^MRU' } | ForEach-Object { $_.Value } }
    if ($servers) { $targets += $servers.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { $_.Name } }
    if ($targets) {
        $rdpHistoryFound = $true
        Write-Report ("[用户 $sid] RDP 连接目标: " + ($targets -join ', '))
        Add-Finding 'INFO' "该账户曾通过 mstsc 连接: $($targets -join ', ')。确认是否本人操作。"
    }
}
if (-not $rdpHistoryFound) { Write-Report "未发现 MSTSC 连接历史。" }

# 7.3 RDP / 远程协助事件日志（v3 修复：不再用 XML 转换，避免解析异常）
Write-Report "`n--- RDP 登录事件（近 $EventDays 天，LogonType 10=远程） ---"
try {
    $secEvents = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624,4625,4778,4779; StartTime=(Get-Date).AddDays(-$EventDays)} -ErrorAction Stop
    $rdpLogons = New-Object System.Collections.Generic.List[object]
    foreach ($evt in @($secEvents)) {
        $m = $evt.Message
        $lt = ''
        $ltm = ([regex]'Logon Type:\s+(\d+)').Match($m)
        if ($ltm.Success) { $lt = $ltm.Groups[1].Value }
        if ($lt -notin @('10','7') -and $evt.Id -notin 4778,4779) { continue }
        $user = ''
        if ($m -match 'New Logon:') {
            $seg = ($m -split 'New Logon:')[-1]
            $um = ([regex]'Account Name:\s+(\S+)').Match($seg)
            if ($um.Success) { $user = $um.Groups[1].Value }
        } else {
            $um = ([regex]'Account Name:\s+(\S+)').Match($m)
            if ($um.Success) { $user = $um.Groups[1].Value }
        }
        $ipm = ([regex]'Source Network Address:\s+(\S+)').Match($m)
        $ip = if ($ipm.Success) { $ipm.Groups[1].Value } else { '' }
        if ($ip -in '-', $null) { $ip = '' }
        $rdpLogons.Add([PSCustomObject]@{ Time=$evt.TimeCreated; Id=$evt.Id; LogonType=$lt; User=$user; SourceIP=$ip })
    }
    foreach ($e in $rdpLogons) {
        $tag = if ($e.Id -eq 4624) { 'RDP登录成功' } elseif ($e.Id -eq 4625) { 'RDP登录失败' } else { '会话断开/重连' }
        Write-Report ("[$tag] $($e.Time) 用户:$($e.User) 来源IP:$($e.SourceIP)")
        if ($e.SourceIP -and $e.SourceIP -notmatch '^127\.|^::1|^$' -and $e.Id -eq 4624) {
            Add-Finding 'HIGH' "存在来自 $($e.SourceIP) 的远程桌面成功登录（用户 $($e.User)，时间 $($e.Time)）。若非本人设备IP，属重大可疑。"
        }
    }
    if ($rdpLogons.Count -eq 0) { Write-Report "近 $EventDays 天内无 RDP 远程登录事件。" }
} catch { Write-Report "Security 日志查询失败（可能无权限或日志为空）: $($_.Exception.Message)" }

Write-Report "`n--- TerminalServices 会话日志（Operational） ---"
try {
    $tsEvents = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-TerminalServices-LocalSessionManager/Operational'; StartTime=(Get-Date).AddDays(-$EventDays)} -ErrorAction Stop
    foreach ($e in $tsEvents) {
        $xml = [xml]$e.Message
        $user  = ($xml.Event.UserData.EventXML.User) -join ','
        $ip    = ($xml.Event.UserData.EventXML.Address) -join ','
        Write-Report ("[TS-LSM Id=$($e.Id)] $($e.TimeCreated) 用户:$user 地址:$ip")
        if ($ip -and $ip -notmatch '^Local|^127\.') { Add-Finding 'MED' "TerminalServices 日志记录到远程地址 ${ip}（用户 $user）" }
    }
} catch { Write-Report "TerminalServices-LSM 日志为空或不可读。" }

Write-Report "`n--- 远程协助 (Quick Assist) 事件 ---"
try {
    $qaEvents = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-RemoteAssistance/Operational'; StartTime=(Get-Date).AddDays(-$EventDays)} -ErrorAction Stop
    foreach ($e in $qaEvents) { Write-Report ("[QA Id=$($e.Id)] $($e.TimeCreated) $($e.Message -replace '\s+',' ')" ) }
    Add-Finding 'MED' "近 $EventDays 天内存在远程协助事件记录，请逐条核实是否本人发起。"
} catch { Write-Report "远程协助事件日志为空。" }

# 7.4 服务安装事件（DeepBlueCLI 启发式）
Write-Report "`n--- 服务安装事件（System 7045，近 30 天） ---"
try {
    $svcInstalls = Get-WinEvent -FilterHashtable @{LogName='System'; Id=7045; StartTime=(Get-Date).AddDays(-30)} -ErrorAction Stop
    $installCount = 0
    foreach ($e in @($svcInstalls)) {
        $installCount++
        $m = $e.Message
        $svcName = ([regex]'Service Name:\s*([^\r\n]+)').Match($m).Groups[1].Value.Trim()
        $imgPath = ([regex]'Service File Name:\s*([^\r\n]+)').Match($m).Groups[1].Value.Trim()
        $svcAcct = ([regex]'Service Start Account:\s*([^\r\n]+)').Match($m).Groups[1].Value.Trim()
        Write-Report ("[7045] $($e.TimeCreated) 服务:$svcName 账户:$svcAcct 路径:$imgPath")
        $script:PersistItems.Add([PSCustomObject]@{ Type='SvcInstallEvent'; Name=$svcName; Detail=$imgPath })
        if ($imgPath -match '\\Temp\\|\\AppData\\|\\Users\\Public\\|powershell|cmd\.exe|\.ps1|mshta|rundll32') {
            Add-Finding 'HIGH' "近期安装的服务路径可疑: $svcName -> $imgPath（时间 $($e.TimeCreated)）"
        }
    }
    if ($installCount -eq 0) { Write-Report '近 30 天无服务安装事件。' }
} catch { Write-Report "System 7045 查询失败: $($_.Exception.Message)" }

# 7.5 PowerShell 脚本块日志启发式（混淆/下载特征）
Write-Report "`n--- PowerShell 脚本块日志（4104，近 3 天，混淆/下载启发式） ---"
$psPat = $script:SwPatterns.psSuspiciousPattern
try {
    $psEvents = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-PowerShell/Operational'; Id=4104; StartTime=(Get-Date).AddDays(-3)} -ErrorAction Stop
    $hitCount = 0
    foreach ($e in @($psEvents)) {
        if ($e.Message -match $psPat) {
            $hitCount++
            if ($hitCount -le 10) {
                $flat = $e.Message -replace '\s+',' '
                $snippet = $flat.Substring(0, [Math]::Min(220, $flat.Length))
                Write-Report ("[PS4104-SUS] $($e.TimeCreated) $snippet")
            }
        }
    }
    if ($hitCount -gt 0) { Add-Finding 'MED' "近 3 天 PowerShell 日志中 $hitCount 条命中混淆/下载特征（显示前 10 条）。核实是否本人脚本。" }
    else { Write-Report '近 3 天无命中。' }
} catch { Write-Report "PowerShell 4104 查询失败: $($_.Exception.Message)" }

# 7.6 登录失败统计（密码喷洒/爆破启发式）
Write-Report "`n--- 登录失败统计（4625，近 $EventDays 天） ---"
try {
    $fails = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625; StartTime=(Get-Date).AddDays(-$EventDays)} -ErrorAction Stop
    $byIP = @{}; $byUser = @{}
    foreach ($e in @($fails)) {
        $m = $e.Message
        $ipm = ([regex]'Source Network Address:\s+(\S+)').Match($m)
        $ip = if ($ipm.Success) { $ipm.Groups[1].Value } else { '' }
        $um = ([regex]'Account Name:\s+(\S+)').Match($m)
        $u = if ($um.Success) { $um.Groups[1].Value } else { '?' }
        if ($ip -and $ip -notmatch '^-$|^$|^127\.' -and $ip -notmatch '^::1') {
            if ($byIP.ContainsKey($ip)) { $byIP[$ip]++ } else { $byIP[$ip] = 1 }
        }
        if ($u -and $u -notmatch '\$$') {
            if ($byUser.ContainsKey($u)) { $byUser[$u]++ } else { $byUser[$u] = 1 }
        }
    }
    Write-Report ("4625 失败总数: $(@($fails).Count)")
    foreach ($x in ($byIP.GetEnumerator() | Where-Object Value -ge 10)) {
        Add-Finding 'HIGH' "来源IP $($x.Key) 近 $EventDays 天触发 $($x.Value) 次登录失败，疑似密码喷洒/爆破。"
        Write-Report ("[SPRAY-IP] $($x.Key) x$($x.Value)")
    }
    foreach ($x in ($byUser.GetEnumerator() | Where-Object { $_.Value -ge 10 })) {
        Write-Report ("[BRUTE-USER] 账户 $($x.Key) 失败 $($x.Value) 次")
    }
} catch { Write-Report "4625 统计失败: $($_.Exception.Message)" }

# ------------------------------------------------ 8. 账户排查
Write-Section '8. 账户与权限排查'

Write-Report "--- 本地账户（注意 \$ 结尾的隐藏账户） ---"
Get-LocalUser -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Report ("[USER] $($_.Name) | Enabled:$($_.Enabled) | LastLogon:$($_.LastLogon) | 描述:$($_.Description)")
    if ($_.Name -match '\$$') { Add-Finding 'HIGH' "发现隐藏账户（以`$结尾）: $($_.Name)。常见于远控木马创建，立即禁用并排查。" }
    if ($_.LastLogon -gt (Get-Date).AddDays(-$EventDays) -and $_.Enabled) {
        Write-Report ("         近期登录: $($_.LastLogon)")
    }
}
$netUser = net user 2>$null
Write-Report ($netUser -join "`r`n")

Write-Report "`n--- 远程桌面用户组与管理员组 ---"
foreach ($grp in 'Remote Desktop Users','Administrators') {
    try {
        $members = Get-LocalGroupMember -Group $grp -ErrorAction Stop
        Write-Report ("[$grp] " + (($members | ForEach-Object { "$($_.ObjectClass):$($_.Name)" }) -join ' | '))
        foreach ($m in $members) {
            if ($grp -eq 'Remote Desktop Users' -and $m.Name -notmatch 'Administrator|管理员') {
                Add-Finding 'MED' "Remote Desktop Users 组含非默认账户: $($m.Name)。非必要请移出。"
            }
        }
    } catch { Write-Report ("[$grp] 读取失败") }
}

# ------------------------------------------------ 9. 摄像头 / 麦克风 / 屏幕捕获隐私
Write-Section '9. 摄像头 / 麦克风 / 屏幕捕获权限与最近使用'

$deviceGuids = @{
    '{E5323777-F976-4f5b-9B55-B94699C46E44}' = '摄像头'
    '{2EEF81BE-33FA-4800-9670-1CD474972C3F}' = '麦克风'
    '{BFA794E4-F964-4FDB-9F6C-315C9E66A455}' = '位置'
    '{C2D07C7F-B6B5-4F0E-8A8C-6A1F6CBA1F4B}' = '帐户信息(参考)'
}
$daPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global'
foreach ($guid in $deviceGuids.Keys) {
    $key = Join-Path $daPath $guid
    $props = Get-ItemProperty $key -ErrorAction SilentlyContinue
    if (-not $props) { continue }
    Write-Report "--- $($deviceGuids[$guid]) 权限 ($guid) ---"
    foreach ($prop in $props.PSObject.Properties) {
        if ($prop.Name -match '^PS') { continue }
        if ($prop.Value -eq 'Allow') {
            $appName = $prop.Name
            Write-Report ("  [ALLOW] $appName")
            if ($appName -notmatch 'S-1-15-2-?(Microsoft|Windows)|NonPackaged' -and $deviceGuids[$guid] -in '摄像头','麦克风') {
                Add-Finding 'MED' "$($deviceGuids[$guid])权限被授予应用: $appName，确认是否本人授权。"
            }
        }
    }
    # 最近使用时间（当前用户 hive）
    $userKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\$guid"
    $lastUsed = Get-ItemProperty $userKey -ErrorAction SilentlyContinue
    if ($lastUsed -and $lastUsed.PSObject.Properties.Name -contains 'LastUsedTimeStop') {
        $ft = $lastUsed.LastUsedTimeStop
        if ($ft -gt 0) {
            try {
                $usedTime = [DateTime]::FromFileTimeUtc($ft).ToLocalTime()
                Write-Report ("  [最近使用] $($deviceGuids[$guid]): $usedTime")
                if ($usedTime -gt (Get-Date).AddDays(-1)) {
                    Add-Finding 'MED' "$($deviceGuids[$guid])在最近 24 小时内有使用记录: $usedTime。若非本人使用，高度可疑。"
                }
            } catch {}
        }
    }
}

Write-Report "`n--- 桌面应用摄像头/麦克风访问开关 ---"
$capPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam'
$micPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone'
foreach ($p in $capPath, $micPath) {
    $v = (Get-ItemProperty $p -Name Value -ErrorAction SilentlyContinue).Value
    $nonPackaged = Get-ChildItem "$p\NonPackaged" -ErrorAction SilentlyContinue | ForEach-Object {
        $vv = (Get-ItemProperty $_.PSPath -Name Value -ErrorAction SilentlyContinue).Value
        "$($_.PSChildName)=$vv"
    }
    Write-Report ("[$p] 总开关:$v  桌面应用明细: $($nonPackaged -join ' | ')")
}

Write-Report "`n--- Xbox Game Bar / 游戏录制（系统自带录屏） ---"
$gameDvr = Get-ItemProperty 'HKCU:\System\GameConfigStore' -ErrorAction SilentlyContinue
Write-Report ("GameDVR_Enabled (系统游戏录制): $($gameDvr.GameDVR_Enabled)")
$appCapture = Get-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR' -ErrorAction SilentlyContinue
Write-Report ("AppCaptureEnabled (后台录制): $($appCapture.AppCaptureEnabled)")
if ($appCapture.AppCaptureEnabled -eq 1) { Add-Finding 'INFO' '系统后台录制(GameDVR)处于开启状态，占用资源并持续截屏，非必要建议关闭。' }

# ------------------------------------------------ 11. 持久化基线（借鉴 PersistenceSniper Diff 思想）
Write-Section '11. 持久化基线导出/对比'

if ($ExportBaseline) {
    $script:PersistItems | Export-Csv -Path $BaselinePath -NoTypeInformation -Encoding UTF8
    Write-Report ("已导出基线（$($script:PersistItems.Count) 项）: $BaselinePath")
    Write-Report '用法：在刚装好的干净系统上运行 脚本 -ExportBaseline 建基线；之后定期运行 脚本 -CompareBaseline，只报告新增持久化项。'
} elseif ($CompareBaseline -and (Test-Path $BaselinePath)) {
    $baseline = Import-Csv $BaselinePath
    $baseKeys = @($baseline | ForEach-Object { "$($_.Type)|$($_.Name)" })
    $newItems = @($script:PersistItems | Where-Object { "$($_.Type)|$($_.Name)" -notin $baseKeys })
    if ($newItems.Count -gt 0) {
        foreach ($n in $newItems) {
            Add-Finding 'HIGH' "基线外新增持久化项 [$($n.Type)]: $($n.Name) -> $($n.Detail)"
            Write-Report ("[NEW-PERSIST] [$($n.Type)] $($n.Name) | $($n.Detail)")
        }
    } else {
        Write-Report '与基线一致，无新增持久化项。'
    }
} else {
    Write-Report ("当前持久化条目总数: $($script:PersistItems.Count)。参数 -ExportBaseline 建立基线，-CompareBaseline 对比新增（基线文件: $BaselinePath）")
}

# ------------------------------------------------ 10. 总结与报告固化
Write-Section '10. 排查总结'

$highCount = @($script:Findings | Where-Object { $_ -match '^\[HIGH\]' }).Count
$medCount  = @($script:Findings | Where-Object { $_ -match '^\[MED\]' }).Count
$infoCount = @($script:Findings | Where-Object { $_ -match '^\[INFO\]' }).Count
Write-Report ("高危发现: $highCount 条 | 中危: $medCount 条 | 提示: $infoCount 条")

$summaryText = @"
================================================================================
 排查总结（生成时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')）
 主机: $env:COMPUTERNAME  用户: $env:USERDOMAIN\$env:USERNAME
  高危 $highCount 条 / 中危 $medCount 条 / 提示 $infoCount 条
================================================================================
"@
Add-Content -Path $FindingsFile -Value $summaryText
if ($script:Findings.Count -gt 0) {
    Add-Content -Path $FindingsFile -Value "`n[全部发现按时间顺序]`n"
    Add-Content -Path $FindingsFile -Value ($script:Findings -join "`r`n")
} else {
    Add-Content -Path $FindingsFile -Value "`n本次排查未发现可疑项（在脚本覆盖范围内）。`n"
}

Write-Host "`n========================================" -ForegroundColor Green
Write-Host " 排查完成。重点查看:" -ForegroundColor Green
Write-Host "   1) $FindingsFile" -ForegroundColor Yellow
Write-Host "   2) $ReportFile" -ForegroundColor Yellow
Write-Host "   3) $NetworkCsv" -ForegroundColor Yellow
Write-Host "========================================`n" -ForegroundColor Green

if ($highCount -gt 0) {
    Write-Host "!!! 存在 $highCount 条高危发现，建议按以下顺序处置:" -ForegroundColor Red
    Write-Host "  1. 立即断开网络（拔网线/关Wi-Fi），阻止持续外传；" -ForegroundColor Red
    Write-Host "  2. 不要关机重启，保留现场（内存易失证据）；" -ForegroundColor Red
    Write-Host "  3. 用另一台干净设备修改重要账户密码（先查键盘记录风险）；" -ForegroundColor Red
    Write-Host "  4. 备份 findings.txt 与 network.csv（计算哈希存证）；" -ForegroundColor Red
    Write-Host "  5. 从 findings.txt 逐条核实，确认实锤后再重装或深度清理。" -ForegroundColor Red
}

# 报告完整性校验（取证意识：固化本次排查输出）
$reportHash = (Get-FileHash -Path $ReportFile -Algorithm SHA256).Hash
Add-Content -Path $FindingsFile -Value "`n[报告完整性] AuditReport.txt SHA256 = $reportHash"
Write-Report ("AuditReport.txt SHA256: $reportHash")
# ---- 结构化输出（-OutputJson / manifest 保证可重复性）----
$jsonResult = [PSCustomObject]@{
    tool        = 'ScreenWatchdog'
    version     = $script:SwVersion
    host        = $env:COMPUTERNAME
    user        = "$env:USERDOMAIN\$env:USERNAME"
    auditedAt   = (Get-Date -Format 'o')
    durationSec = [int]((Get-Date) - $AuditStart).TotalSeconds
    reportSha256= $reportHash
    summary     = [PSCustomObject]@{ high=$highCount; medium=$medCount; info=$infoCount }
    findings    = $script:Findings
}
$manifestPath = Join-Path $OutputDir 'manifest.json'
$jsonResult | ConvertTo-Json -Depth 4 | Out-File $manifestPath -Encoding UTF8
if ($OutputJson) {
    $jsonPath = Join-Path $OutputDir 'audit_result.json'
    $jsonResult | ConvertTo-Json -Depth 4 | Out-File $jsonPath -Encoding UTF8
    Write-Report "JSON 结果已输出: $jsonPath"
}
Write-Report "`n排查结束。本工具为只读审计，未修改系统任何配置或数据。"
